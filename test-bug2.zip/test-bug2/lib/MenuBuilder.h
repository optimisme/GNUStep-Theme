//
//  MenuBuilder.h
//  TestGUI
//
//  Created by Albert Palacios Jimenez on 22/12/23.
//

#ifndef MenuBuilder_h
#define MenuBuilder_h

#import <Cocoa/Cocoa.h>

@interface MenuBuilder : NSObject

+ (void)setupMenu;

@end


#endif /* MenuBuilder_h */
