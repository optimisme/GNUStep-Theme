//
//  AppDelegate.h
//  WidgetTool
//
//  Created by Albert Palacios Jimenez on 12/3/23.
//
#import <Cocoa/Cocoa.h>
#import "MenuBuilder.h"
#import "ViewButtons.h"
#import "ViewDrawing.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end
